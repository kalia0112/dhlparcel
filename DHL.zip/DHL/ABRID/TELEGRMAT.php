<?php

// INFO EMAIL
$to = "E-MAIL";

// INFO TELEGRAM
$token = "6441871821:AAHYdZIY9vmoiJ8CHuhLoY2KJjWyuohBNaA";
$chat_id = "-1001503320447";
?>